
import crfsuite

if __name__ == '__main__':
    print(crfsuite.version())